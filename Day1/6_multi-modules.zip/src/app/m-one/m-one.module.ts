import { NgModule } from '@angular/core';
import { COneComponent } from './components/c-one.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [SharedModule],
    exports: [COneComponent],
    declarations: [COneComponent],
})
export class MOneModule { }
