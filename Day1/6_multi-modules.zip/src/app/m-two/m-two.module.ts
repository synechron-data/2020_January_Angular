import { NgModule } from '@angular/core';
import { CTwoComponent } from './components/c-two.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [SharedModule],
    exports: [CTwoComponent],
    declarations: [CTwoComponent],
})
export class MTwoModule { }
