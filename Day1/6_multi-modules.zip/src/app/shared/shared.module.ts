import { NgModule } from '@angular/core';
import { SComComponent } from './components/s-com.component';

@NgModule({
    imports: [],
    exports: [SComComponent],
    declarations: [SComComponent],
})
export class SharedModule { }
