import { Component, OnInit } from '@angular/core';

@Component({
    selector: 's-com',
    template: `
        <h2 class="text-warning">Shared Component - Shared Module</h2>
    `
})

export class SComComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}