import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <c-one>Component One will be Loaded....</c-one>
            <c-two>Component Two will be Loaded....</c-two>
            <hr>
            <c-one>Component One will be Loaded Again....</c-one>
            <c-two>Component Two will be Loaded Again....</c-two>
        </div>
    `
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}