import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'caption',
    pure: true
})

export class CaptionPipe implements PipeTransform {
    transform(value: boolean, ...args: any[]): string {
        if (value)
            return "Short Date";
        else
            return "Full Date";
    }
}