import { Component, OnInit } from '@angular/core';
import { Observable, Observer, Subject } from 'rxjs';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Promise And Observables</h1>
            </div>

        </div>
    `
})

export class RootComponent implements OnInit {
    observable: Observable<number>;
    subject: Subject<number>;

    constructor() {
    }

    ngOnInit() {
        this.subject = new Subject<number>();

        setInterval(() => {
            this.subject.next(Math.random());
        }, 2000);

        this.subject.subscribe((data) => {
            console.log("Sub 1 - ", data);
        });

        this.subject.subscribe((data) => {
            console.log("Sub 2 - ", data);
        });

        // this.observable = Observable.create((ob: Observer<number>) => {
        //     setInterval(function () {
        //         // console.log("Data Stream Started...");
        //         ob.next(Math.random());
        //     }, 2000);
        // });

        // this.observable.subscribe((data) => {
        //     console.log("Sub 1 - ", data);
        // });

        // this.observable.subscribe((data) => {
        //     console.log("Sub 2 - ", data);
        // });

        // this.getData((data:number)=>{
        //     console.log("Callback Output - ", data);
        // });

        // var p = this.getPromise();
        // p.then((data) => {
        //     console.log("Promise Output - ", data);
        // }, (err) => {
        //     console.log(err);
        // })
    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(function () {
                resolve(Math.random());
            }, 2000);
        })
    }

    getData(sCB: (n: number) => void, eCB?: any) {
        setInterval(function () {
            sCB(Math.random());
        }, 2000);
    }
}