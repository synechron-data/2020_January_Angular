import { Component, OnInit, AfterViewInit, NgZone, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>

            <div [hidden]=flag>
                <h3 class="alert alert-danger" *ngIf="message">{{message}}</h3>
                <counter #c1 (maxedOut)=onMax($event) [(cflag)]="p_flag"></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button [disabled]="!p_flag" class="btn btn-warning btn-block" (click)="p_reset(c1)">Parent Reset</button>
                    </div>
                </div>
            </div>

            <div [hidden]=!flag>
                <counter #c1></counter>
                <counter #c2></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset</button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="p_reset(c1)">Parent Reset</button>
                    </div>
                </div>
            </div>

            <div [hidden]=!flag>
                <counter></counter>
                <counter [interval]="5"></counter>
            </div>
            <!-- <list [personList]="pList"></list> -->
        </div>
    `
})

export class RootComponent implements OnInit, AfterViewInit {
    // @ViewChild(CounterComponent)
    // counter: CounterComponent;

    // @ViewChild("c2")
    // counter: CounterComponent;

    @ViewChildren(CounterComponent)
    counters: QueryList<CounterComponent>;

    pList: Array<string>;
    message: string;
    p_flag: boolean;

    constructor() {
        this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
        this.message = "";
        this.p_flag = false;    
    }

    ngOnInit() { }

    ngAfterViewInit(): void {
        // this.counter.interval = 10;
        // for (const counter of this.counters.toArray()) {
        //     counter.interval = 10;
        // }
    }

    p_reset(c: CounterComponent) {
        console.log(c);
        c.reset();
    }

    onMax(flag: boolean) {
        if (flag) {
            this.message = "Max Click Reached, please reset to continue...";
        } else {
            this.message = "";
        }
    }
}