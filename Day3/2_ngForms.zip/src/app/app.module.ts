import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { RootComponent } from "./components/root/root.component";
import { TemplatedFormComponent } from "./components/templated/templated-form.component";
import { ReactiveFormComponent } from "./components/reactive/reactive-form.component";
import { ValidationFormComponent } from "./components/validation/validation-form.component";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [RootComponent, TemplatedFormComponent, 
        ReactiveFormComponent, ValidationFormComponent],
    bootstrap: [RootComponent],
    providers: [{
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}