import { NgModule, APP_BOOTSTRAP_LISTENER, Component, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RootComponent } from "./components/root/root.component";
import { COneComponent } from "./components/c-one/c-one.component";
import { CTwoComponent } from "./components/c-two/c-two.component";

@NgModule({
    imports: [BrowserModule],
    declarations: [RootComponent, COneComponent, CTwoComponent],
    bootstrap: [RootComponent],
    providers: [{
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}