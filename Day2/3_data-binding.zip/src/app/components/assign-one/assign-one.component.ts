import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'assign-one',
    templateUrl: 'assign-one.component.html'
})

export class AssignOneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}