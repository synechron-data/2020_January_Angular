import { NgModule, APP_BOOTSTRAP_LISTENER, Component, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { RootComponent } from "./components/root/root.component";
import { AssignOneComponent } from "./components/assign-one/assign-one.component";
import { AssignTwoComponent } from "./components/assign-two/assign-two.component";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, AssignOneComponent, AssignTwoComponent],
    bootstrap: [RootComponent],
    providers: [{
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}