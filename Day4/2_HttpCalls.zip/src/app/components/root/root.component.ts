import { Component, OnInit, OnDestroy } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Post } from '../../models/post.model';
import { PostService } from '../../services/post.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [PostService]
})

export class RootComponent implements OnInit, OnDestroy {
    message: string;
    url: string;
    posts: Array<Post>;
    gp_sub: Subscription;

    constructor(private pService: PostService) {
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        this.gp_sub = this.pService.getPosts().subscribe((resData) => {
            this.posts = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });

        // this.gp_sub = this.pService.getPosts().subscribe((resData) => {
        //     this.posts = resData;
        //     this.message = "";
        // }, (err: HttpErrorResponse) => {
        //     this.message = err.message;
        // });
    }

    ngOnDestroy(): void {
        this.gp_sub.unsubscribe();
    }
}

// import { Component, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from "@angular/common/http";
// import { Post } from '../../models/post.model';

// @Component({
//     selector: 'root',
//     templateUrl: 'root.component.html',
//     styleUrls: ['./root.component.css']
// })

// export class RootComponent implements OnInit {
//     message: string;
//     url: string;
//     posts: Array<Post>;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.httpClient.get<Array<Post>>(this.url).subscribe((resData) => {
//             this.posts = resData;
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }
// }