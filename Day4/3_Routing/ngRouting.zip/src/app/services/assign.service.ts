import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable()
export class AssignmentService {
    private url: string;
    
    constructor(private httpClient: HttpClient) {
        this.url = "http://localhost:6001/products";
    }

    getAllProducts() {
        return this.httpClient.get<Array<Product>>(this.url).pipe(
            catchError(this.handleError<any>('getAllProducts'))
        )
    }

    private handleError<T>(operation = 'operation', result?: T) {
        return (error: HttpErrorResponse): Observable<T> => {
            console.error(`${operation} failed: ${error.message}`);

            return throwError('Connection Error, please try again later');
        }
    }
    
}