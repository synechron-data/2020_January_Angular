import { Component, OnInit, OnDestroy } from '@angular/core';
import { Author } from '../../models/app.author';
import { AuthorService } from '../../services/author.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'author-quote',
    templateUrl: 'author-quote.component.html',
    styleUrls: ['./author-quote.component.css']
})

export class AuthorQuoteComponent implements OnInit, OnDestroy {
    selectedAuthor: Author;
    sac_sub: Subscription;

    constructor(private aService: AuthorService) { }

    ngOnInit() {
        this.aService.SelectedAuthorChanged.subscribe(() => {
            this.selectedAuthor = this.aService.SelectedAuthor;
        });
    }

    ngOnDestroy(): void {
        // this.sac_sub.unsubscribe();
    }
}