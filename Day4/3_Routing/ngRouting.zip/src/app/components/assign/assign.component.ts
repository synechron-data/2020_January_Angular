import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AssignmentService } from '../../services/assign.service';
import { Product } from '../../models/product.model';

@Component({
    templateUrl: 'assign.component.html',
    providers: [AssignmentService]
})

export class AssignmentComponent implements OnInit, OnDestroy {
    products: Array<Product>;
    message: string;
    gu_subscription: Subscription;

    constructor(private _aService: AssignmentService) { }

    ngOnInit() {
        this.gu_subscription = this._aService.getAllProducts().subscribe((resData) => {
            this.products = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    onDelete(e: Event) {
        e.preventDefault();
        if (window.confirm('Are you sure, you want to delete the product?')) {

        }
    }

    ngOnDestroy(): void {
        this.gu_subscription.unsubscribe();
    }
}