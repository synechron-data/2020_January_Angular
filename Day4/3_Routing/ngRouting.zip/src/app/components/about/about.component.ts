import { Component, OnInit } from '@angular/core';
import { PreviousRouteService } from '../../services/proute.service';

@Component({
    templateUrl: 'about.component.html'
})

export class AboutComponent implements OnInit {
    constructor(private _pRoute: PreviousRouteService) { }

    ngOnInit() { 
        console.log(this._pRoute.getPreviousUrl());
    }
}